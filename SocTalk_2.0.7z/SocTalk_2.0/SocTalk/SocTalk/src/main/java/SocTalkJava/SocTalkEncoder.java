package SocTalkJava;

import javax.json.Json;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

//This class converteds a ChatMessage to a JSON string using the Java API for JSON Processing
//It uses the new JSON builder 
//https://jcp.org/en/jsr/detail?id=353 - System

public class SocTalkEncoder implements Encoder.Text<ChatMessage> {
	@Override
	public void init(final EndpointConfig config) {
	}
	@Override
	public void destroy() {
	}
	@Override
	public String encode(final ChatMessage chatMessage) throws EncodeException {
            //Creates a object using the new JSON builder
		return Json.createObjectBuilder()
				.add("message", chatMessage.getMessage())
				.add("sender", chatMessage.getSender())
				.add("received", chatMessage.getReceived().toString()).build()
				.toString();
	}
}
